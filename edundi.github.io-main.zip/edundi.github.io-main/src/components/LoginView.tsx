/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Lock, Mail, User, Phone, Sparkles, Loader2, Key, 
  AlertCircle, CheckCircle2, Eye, EyeOff, Building, 
  ArrowRight, ShieldCheck, FileText, Gift, HelpCircle, 
  TrendingUp, Moon, Sun, Laptop, Heart, Landmark, Layers
} from 'lucide-react';

interface LoginViewProps {
  onGoogleSignIn: () => void;
  onCredentialSignIn: (credential: string, password: string, rememberMe: boolean) => Promise<any>;
  onResetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  loading: boolean;
}

export default function LoginView({
  onGoogleSignIn,
  onCredentialSignIn,
  onResetPassword,
  loading
}: LoginViewProps) {
  // Tabs: 'login' | 'register'
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  
  // Login form states
  const [credential, setCredential] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  // Registration form states
  const [regName, setRegName] = useState('');
  const [regCompany, setRegCompany] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regWhatsapp, setRegWhatsapp] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regMarketing, setRegMarketing] = useState('Akim');
  const [regReferral, setRegReferral] = useState('');
  const [regAgree, setRegAgree] = useState(false);

  // Forgot Mode
  const [isForgotMode, setIsForgotMode] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');

  // Feedback states
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Theme states
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  // Load theme from preference or system
  useEffect(() => {
    const savedTheme = localStorage.getItem('crm_login_theme') as 'light' | 'dark' | null;
    if (savedTheme) {
      setTheme(savedTheme);
    } else {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(prefersDark ? 'dark' : 'light');
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('crm_login_theme', nextTheme);
  };

  // Preset demo credentials mapped to user roles
  const fastLoginRoles = [
    { label: '👑 Super Admin', user: 'Rizkihandika', pass: '17April1960*' },
    { label: '💻 IT Developer', user: 'Badrul', pass: '17April1960*' },
    { label: '📈 Marketing', user: 'Akim', pass: '17April1960*' },
    { label: '📞 CS Agent', user: 'cs_agent', pass: '17April1960*' },
    { label: '👥 Client Portal', user: 'client_demo', pass: '17April1960*' }
  ];

  const handleFastLogin = (usernameVal: string, passwordVal: string) => {
    setCredential(usernameVal);
    setPassword(passwordVal);
    setError(null);
    setSuccess(`Kredensial demo untuk "${usernameVal}" diisi otomatis!`);
    
    // Smooth scroll back to form on mobile
    const formElement = document.getElementById('login-form-panel');
    if (formElement) {
      formElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSubmitLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!credential || !password) {
      setError('Kredensial dan password harus diisi.');
      return;
    }

    setError(null);
    setSuccess(null);
    setIsSubmitting(true);

    try {
      await onCredentialSignIn(credential, password, rememberMe);
      setSuccess('Login berhasil! Mengalihkan ke Dashboard Nusantara Digital...');
    } catch (err: any) {
      setError(err.message || 'Login gagal. Silakan periksa kembali kredensial Anda.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!regAgree) {
      setError('Anda harus menyetujui syarat dan ketentuan layanan.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setError('Password dan konfirmasi password tidak cocok.');
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName,
          companyName: regCompany,
          email: regEmail,
          whatsapp: regWhatsapp,
          username: regUsername,
          password: regPassword,
          marketingId: regMarketing,
          referralCode: regReferral
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Gagal mendaftar client.');

      setSuccess('Pendaftaran berhasil! Silakan login menggunakan akun baru Anda.');
      
      // Clear registration form
      setRegName('');
      setRegCompany('');
      setRegEmail('');
      setRegWhatsapp('');
      setRegUsername('');
      setRegPassword('');
      setRegConfirmPassword('');
      setRegReferral('');
      setRegAgree(false);

      // Switch tab to login
      setTimeout(() => {
        setActiveTab('login');
      }, 3000);
    } catch (err: any) {
      setError(err.message || 'Gagal melakukan pendaftaran.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) {
      setError('Masukkan alamat email Anda.');
      return;
    }

    setError(null);
    setSuccess(null);
    setIsSubmitting(true);

    try {
      const res = await onResetPassword(forgotEmail);
      if (res.success) {
        setSuccess(res.message || 'Tautan reset password telah dikirim ke email Anda.');
        setForgotEmail('');
      } else {
        setError('Gagal memproses tautan reset password.');
      }
    } catch (err: any) {
      setError(err.message || 'Gagal memproses reset password.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const features = [
    { title: 'Manajemen Project & Board', desc: 'Pantau siklus pengembangan aplikasi & milestone sekolah secara real-time.' },
    { title: 'Invoice & Kwitansi Otomatis', desc: 'Tagihan terintegrasi langsung dengan gateway verifikasi pembayaran.' },
    { title: 'Referral Marketing & Komisi', desc: 'Dapatkan komisi berjenjang dari kode referral rujukan marketing aktif.' },
    { title: 'Monitoring Hosting & Domain', desc: 'Pantau kedaluwarsa cPanel, SSL, DNS, dan server OJS secara berkala.' },
    { title: 'Support Ticket 24/7', desc: 'Hubungan komunikasi instan bantuan teknis terintegrasi dengan Google Workspace.' }
  ];

  return (
    <div className={`min-h-screen transition-colors duration-500 font-sans flex flex-col md:flex-row relative overflow-hidden ${
      theme === 'dark' ? 'bg-[#0F172A] text-slate-100' : 'bg-slate-50 text-slate-800'
    }`} id="premium-login-view">
      
      {/* Glow Backdrops */}
      <div className="absolute w-[800px] h-[800px] bg-teal-500/10 rounded-full blur-3xl -top-80 -left-80 pointer-events-none"></div>
      <div className="absolute w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-3xl -bottom-80 -right-80 pointer-events-none"></div>

      {/* LEFT COLUMN: BRANDING & MARKETING SIDEBAR (Hidden/Minimized on smaller screen) */}
      <div className={`w-full md:w-1/2 p-6 md:p-12 lg:p-16 flex flex-col justify-between relative z-10 border-b md:border-b-0 md:border-r ${
        theme === 'dark' ? 'border-slate-800 bg-[#0F172A]/50' : 'border-slate-200 bg-white/60'
      } backdrop-blur-md`}>
        
        {/* Brand Header */}
        <div className="flex items-center space-x-3.5">
          <img
            src="https://edutechnusantaradigital.github.io/assets/images/logo.png"
            alt="EduTech Logo"
            className="w-12 h-12 rounded-xl shadow-lg border border-teal-500/20 p-0.5 object-contain"
          />
          <div>
            <h1 className="text-lg font-black tracking-wider text-teal-500 flex items-center gap-1 uppercase">
              CRM Nusantara
              <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
            </h1>
            <p className="text-[10px] opacity-75 font-bold uppercase tracking-widest">EduTech Nusantara Digital</p>
          </div>
        </div>

        {/* Dynamic Sidebar Info */}
        <div className="my-8 md:my-12 text-left space-y-6">
          <div className="space-y-3">
            <h2 className="text-2xl md:text-3xl font-black tracking-tight leading-tight">
              Sistem Manajemen Proyek, Tagihan, Client, & Keuangan EduTech Nusantara Digital
            </h2>
            <p className="text-xs opacity-80 leading-relaxed">
              Platform CRM enterprise terpadu untuk merancang, melacak, membiayai, dan mengoptimalkan kolaborasi pendidikan di Indonesia.
            </p>
          </div>

          <hr className={theme === 'dark' ? 'border-slate-800' : 'border-slate-200'} />

          {/* Features checkmark */}
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase tracking-widest text-teal-500">Mengapa menggunakan CRM Nusantara Digital?</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
              {features.map((f, i) => (
                <div key={i} className="flex items-start space-x-2">
                  <div className="p-1 rounded bg-teal-500/10 text-teal-400 shrink-0 mt-0.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="font-extrabold block text-[11px]">{f.title}</span>
                    <span className="opacity-75 text-[10px] block leading-snug">{f.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Live Counters */}
        <div className={`grid grid-cols-4 gap-2.5 p-4 rounded-2xl border text-center select-none relative overflow-hidden mt-auto shadow-inner ${
          theme === 'dark' ? 'border-slate-800/80 bg-slate-950/40 text-slate-100' : 'border-slate-200 bg-slate-50/70 text-slate-800'
        }`}>
          <div className="space-y-1">
            <span className="text-lg md:text-xl font-black text-teal-500 block">1.250+</span>
            <span className="text-[8px] opacity-70 font-black uppercase tracking-wider block">Project Aktif</span>
          </div>
          <div className="border-l border-slate-500/20 space-y-1">
            <span className="text-lg md:text-xl font-black text-teal-500 block">850+</span>
            <span className="text-[8px] opacity-70 font-black uppercase tracking-wider block">Client</span>
          </div>
          <div className="border-l border-slate-500/20 space-y-1">
            <span className="text-lg md:text-xl font-black text-teal-500 block">5.600+</span>
            <span className="text-[8px] opacity-70 font-black uppercase tracking-wider block">Invoice</span>
          </div>
          <div className="border-l border-slate-500/20 space-y-1">
            <span className="text-lg md:text-xl font-black text-teal-500 block">75+</span>
            <span className="text-[8px] opacity-70 font-black uppercase tracking-wider block">Marketing</span>
          </div>
        </div>

        {/* Tiny footer under sidebar info */}
        <div className="mt-6 pt-4 border-t border-slate-500/10 flex flex-wrap items-center justify-between text-[10px] opacity-60">
          <span>&copy; 2026 EduTech Nusantara Digital</span>
          <span className="font-bold">Enterprise CRM v1.0</span>
        </div>

      </div>

      {/* RIGHT COLUMN: LOGIN & REGISTER FORMS PANEL */}
      <div className="w-full md:w-1/2 p-6 md:p-12 lg:p-16 flex flex-col justify-center relative z-10" id="login-form-panel">
        
        {/* Floating Controls: Theme and language toggle */}
        <div className="absolute top-4 right-4 md:top-6 md:right-8 flex items-center space-x-2 z-20">
          <button
            onClick={toggleTheme}
            className={`p-2.5 rounded-xl border transition ${
              theme === 'dark' ? 'border-slate-800 bg-slate-900/80 hover:bg-slate-800 text-yellow-400' : 'border-slate-200 bg-white/80 hover:bg-slate-100 text-indigo-600'
            } shadow-md`}
            title="Ubah Tema"
          >
            {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
          </button>
        </div>

        <div className="max-w-md w-full mx-auto space-y-6">
          
          {/* Card Frame with Glassmorphism */}
          <div className={`p-6 md:p-8 rounded-3xl border shadow-2xl transition duration-300 backdrop-blur-xl hover:border-teal-500/30 ${
            theme === 'dark' ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'
          }`}>

            {/* Header Title inside Form Card */}
            <div className="text-center space-y-2 mb-6">
              <h2 className="text-2xl font-black tracking-tight">
                {isForgotMode ? 'Reset Password' : activeTab === 'login' ? 'Masuk ke Dashboard' : 'Daftar Client Baru'}
              </h2>
              <p className="text-xs opacity-75">
                {isForgotMode ? 'Masukkan email terdaftar Anda' : activeTab === 'login' ? 'Kelola proyek dan tagihan terpadu Nusantara' : 'Pendaftaran instan akun client enterprise'}
              </p>
            </div>

            {/* Tabs for Login / Register (Only visible when not in forgot mode) */}
            {!isForgotMode && (
              <div className={`p-1 rounded-xl flex items-center space-x-1 mb-6 ${
                theme === 'dark' ? 'bg-slate-950/80' : 'bg-slate-100'
              }`}>
                <button
                  type="button"
                  onClick={() => { setActiveTab('login'); setError(null); setSuccess(null); }}
                  className={`flex-1 py-2 text-xs font-black rounded-lg transition-all duration-300 ${
                    activeTab === 'login' 
                      ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md' 
                      : 'opacity-70 hover:opacity-100'
                  }`}
                >
                  Masuk (Sign In)
                </button>
                <button
                  type="button"
                  onClick={() => { setActiveTab('register'); setError(null); setSuccess(null); }}
                  className={`flex-1 py-2 text-xs font-black rounded-lg transition-all duration-300 ${
                    activeTab === 'register' 
                      ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md' 
                      : 'opacity-70 hover:opacity-100'
                  }`}
                >
                  Daftar Client
                </button>
              </div>
            )}

            {/* Notifications and Alerts */}
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3.5 mb-4 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl flex items-start space-x-2.5"
              >
                <AlertCircle size={16} className="shrink-0 mt-0.5" />
                <span className="whitespace-pre-line text-left font-semibold">{error}</span>
              </motion.div>
            )}
            {success && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3.5 mb-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl flex items-start space-x-2.5"
              >
                <CheckCircle2 size={16} className="shrink-0 mt-0.5" />
                <span className="text-left font-semibold">{success}</span>
              </motion.div>
            )}

            {isForgotMode ? (
              /* FORGOT PASSWORD FORM */
              <form onSubmit={handleResetSubmit} className="space-y-4 text-left">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-black uppercase tracking-wider opacity-80">
                    Alamat Email Terdaftar
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 opacity-50">
                      <Mail size={15} />
                    </span>
                    <input
                      type="email"
                      required
                      placeholder="nama@instansi.sch.id"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className={`w-full pl-10 pr-4 py-2.5 rounded-xl text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 disabled:opacity-50 text-white text-xs font-black uppercase tracking-wider transition cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-teal-600/20"
                >
                  {isSubmitting ? <Loader2 className="animate-spin w-4 h-4" /> : <span>Kirim Link Reset Password</span>}
                </button>

                <button
                  type="button"
                  onClick={() => { setIsForgotMode(false); setError(null); setSuccess(null); }}
                  className="w-full text-center text-[11px] font-bold text-teal-500 hover:underline transition"
                >
                  Kembali ke Halaman Login Utama
                </button>
              </form>

            ) : activeTab === 'login' ? (

              /* LOGIN FORM */
              <form onSubmit={handleSubmitLogin} className="space-y-4.5 text-left">
                
                {/* Credential input */}
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-black uppercase tracking-wider opacity-85">
                    Username / Email / Nomor WhatsApp
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 opacity-60">
                      <User size={15} />
                    </span>
                    <input
                      type="text"
                      required
                      placeholder="Masukkan Username, Email atau Nomor WhatsApp"
                      value={credential}
                      onChange={(e) => setCredential(e.target.value)}
                      className={`w-full pl-10 pr-4 py-3 rounded-xl text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                  </div>
                </div>

                {/* Password input */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label className="block text-[10px] font-black uppercase tracking-wider opacity-85">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsForgotMode(true)}
                      className="text-[10px] text-teal-500 font-extrabold hover:underline"
                    >
                      Lupa Password?
                    </button>
                  </div>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 opacity-60">
                      <Key size={15} />
                    </span>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="Masukkan Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className={`w-full pl-10 pr-12 py-3 rounded-xl text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-200"
                      title="Lihat Password"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {/* Remember me Checkbox */}
                <div className="flex items-center justify-between py-1">
                  <label className="flex items-center space-x-2.5 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded text-teal-600 bg-slate-950 border-slate-800 focus:ring-teal-500 cursor-pointer"
                    />
                    <span className="text-[11px] opacity-80 font-bold">Ingat Saya</span>
                  </label>
                </div>

                {/* Submit login */}
                <button
                  type="submit"
                  disabled={isSubmitting || loading}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 disabled:opacity-50 text-white text-xs font-black uppercase tracking-widest transition cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-teal-600/25"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="animate-spin w-4 h-4 mr-1" />
                      <span>Memproses Autentikasi...</span>
                    </>
                  ) : (
                    <span>Masuk ke Dashboard</span>
                  )}
                </button>
              </form>

            ) : (

              /* REGISTER CLIENT FORM */
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-left max-h-[420px] overflow-y-auto pr-1 scrollbar-thin">
                
                {/* Nama Lengkap */}
                <div className="space-y-1">
                  <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Nama Lengkap</label>
                  <input
                    type="text"
                    required
                    placeholder="Masukkan nama lengkap"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                      theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}
                  />
                </div>

                {/* Nama Instansi */}
                <div className="space-y-1">
                  <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Nama Instansi</label>
                  <input
                    type="text"
                    required
                    placeholder="Masukkan nama instansi (contoh: SMK TI Malang)"
                    value={regCompany}
                    onChange={(e) => setRegCompany(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                      theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}
                  />
                </div>

                {/* Email & WhatsApp Row */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Email Resmi</label>
                    <input
                      type="email"
                      required
                      placeholder="email@sekolah.sch.id"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Nomor WhatsApp</label>
                    <input
                      type="text"
                      required
                      placeholder="0878..."
                      value={regWhatsapp}
                      onChange={(e) => setRegWhatsapp(e.target.value)}
                      className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                  </div>
                </div>

                {/* Username */}
                <div className="space-y-1">
                  <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Username Akun</label>
                  <input
                    type="text"
                    required
                    placeholder="Masukkan Username baru"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                      theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}
                  />
                </div>

                {/* Password & Confirm Row */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Password</label>
                    <input
                      type="password"
                      required
                      placeholder="Masukkan Password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[9px] font-black uppercase tracking-wider opacity-80">Konfirmasi</label>
                    <input
                      type="password"
                      required
                      placeholder="Ulangi Password"
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      className={`w-full px-3 py-2 rounded-lg text-xs outline-none transition border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
                      }`}
                    />
                  </div>
                </div>

                {/* Pilih Marketing Dropdown & Referral Row */}
                <div className="grid grid-cols-2 gap-3 p-3 bg-teal-500/5 rounded-xl border border-teal-500/10">
                  <div className="space-y-1">
                    <label className="block text-[9px] font-black uppercase tracking-wider text-teal-400">Pilih Marketing</label>
                    <select
                      value={regMarketing}
                      onChange={(e) => setRegMarketing(e.target.value)}
                      className={`w-full p-2 rounded-lg text-[11px] font-bold outline-none border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/80 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
                      }`}
                    >
                      <option value="Akim">Akim (Active Marketing)</option>
                      <option value="Rizkihandika">Rizki Handika (General Manager)</option>
                      <option value="Badrul">Badrul Muhayyat (Developer)</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[9px] font-black uppercase tracking-wider text-teal-400">Kode Referral (Opsional)</label>
                    <input
                      type="text"
                      placeholder="Contoh: AKIM25"
                      value={regReferral}
                      onChange={(e) => setRegReferral(e.target.value)}
                      className={`w-full p-2 rounded-lg text-xs outline-none border focus:ring-1 focus:ring-teal-500 ${
                        theme === 'dark' ? 'bg-slate-950/80 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
                      }`}
                    />
                  </div>
                </div>

                {/* Centang Agree */}
                <label className="flex items-start space-x-2.5 cursor-pointer select-none py-1">
                  <input
                    type="checkbox"
                    checked={regAgree}
                    onChange={(e) => setRegAgree(e.target.checked)}
                    className="w-4 h-4 rounded text-teal-600 bg-slate-950 border-slate-800 focus:ring-teal-500 cursor-pointer mt-0.5"
                  />
                  <span className="text-[10px] opacity-80 leading-normal">
                    Saya menyetujui syarat, ketentuan, serta kebijakan privasi data CRM Nusantara Digital.
                  </span>
                </label>

                {/* Submit Register */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 disabled:opacity-50 text-white text-xs font-black uppercase tracking-widest transition cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-teal-600/20"
                >
                  {isSubmitting ? <Loader2 className="animate-spin w-4 h-4" /> : <span>Daftar Sekarang</span>}
                </button>
              </form>
            )}

            {/* Divider */}
            <div className="relative flex py-4 items-center">
              <div className={`flex-grow border-t ${theme === 'dark' ? 'border-slate-800' : 'border-slate-200'}`}></div>
              <span className="flex-shrink mx-4 text-[9px] font-bold uppercase tracking-widest opacity-50">Atau lanjutkan dengan</span>
              <div className={`flex-grow border-t ${theme === 'dark' ? 'border-slate-800' : 'border-slate-200'}`}></div>
            </div>

            {/* Google workspace sign-in alternative */}
            <button
              type="button"
              onClick={onGoogleSignIn}
              className={`w-full py-2.5 rounded-xl border font-bold text-xs transition duration-200 flex items-center justify-center space-x-2.5 cursor-pointer shadow-md ${
                theme === 'dark' 
                  ? 'border-slate-800 bg-slate-950 hover:bg-slate-900 text-slate-200' 
                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
              }`}
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" />
              </svg>
              <span>Login dengan Google</span>
            </button>
          </div>

          {/* DEMO / QUICK LOGIN OPTIONS CARD */}
          {!isForgotMode && (
            <div className={`p-5 rounded-2xl border text-left space-y-3.5 ${
              theme === 'dark' ? 'bg-slate-950/40 border-slate-800/80' : 'bg-slate-100/50 border-slate-200'
            }`}>
              <div className="flex items-center space-x-1 text-teal-500">
                <Layers className="w-4 h-4 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-wider">Akses Login Cepat (Pengembangan / Demo)</span>
              </div>
              <p className="text-[9px] opacity-75 leading-relaxed">
                Gunakan tombol role di bawah untuk mengisi kredensial secara instan guna uji coba fungsionalitas penuh.
              </p>
              
              {/* Cards grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {fastLoginRoles.map((roleObj, rid) => (
                  <button
                    key={rid}
                    type="button"
                    onClick={() => handleFastLogin(roleObj.user, roleObj.pass)}
                    className={`p-2 rounded-xl text-[10px] font-extrabold border transition text-left leading-normal ${
                      theme === 'dark'
                        ? 'border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-200 hover:border-teal-500/40'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700 hover:border-teal-500/40'
                    }`}
                  >
                    <span className="block truncate">{roleObj.label}</span>
                    <span className="block text-[8px] opacity-60 font-mono mt-0.5">User: {roleObj.user}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Enterprise Help Footer */}
          <div className="text-center space-y-1.5 opacity-60 text-[10px] pt-2">
            <p className="flex items-center justify-center space-x-1.5">
              <span>WhatsApp Resmi:</span>
              <span className="font-extrabold text-teal-500 hover:underline">0878-5093-4303</span>
            </p>
            <p>
              <a href="https://edutechnusantaradigital.com" target="_blank" rel="noreferrer" className="hover:underline hover:text-teal-500 font-bold">
                https://edutechnusantaradigital.com
              </a>
            </p>
          </div>

        </div>
      </div>
    </div>
  );
}
